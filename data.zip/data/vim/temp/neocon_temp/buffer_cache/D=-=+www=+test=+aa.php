[{'word': 'code', 'menu': '[B] aa.php', 'kind': '', 'abbr': 'code'}]
